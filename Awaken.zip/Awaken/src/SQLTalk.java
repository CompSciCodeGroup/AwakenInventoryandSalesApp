/**
 * Created by Chase on 4/11/2017.
 */

import com.sun.org.apache.bcel.internal.util.ClassPath;
import sun.security.krb5.internal.EncAPRepPart;
import java.sql.*;

public class SQLTalk {
    private static Clothing[] clothes = new Clothing[1000];

    public static void main(String args[]) throws SQLException {
        SQLTalk connection = new SQLTalk();

        connection.searchColor("WHITE");
        Clothing clothing = new Clothing("02/15/17", "AWAKEN", "BUSINESS CASUAL", "40.99", "40.99", "FALL", "FEMALE", "SWEATER", "WOOL", "003", "F255003", "WHITE", "01", "F255003FFFFFF01");
        System.out.println(clothing.toInputString());
        connection.addClothes(clothing);

        for (int i = 0; i < clothes.length; i++) {
            if (clothes[i].getSKU() != null) {
                System.out.println(clothes[i].toString());
            }
        }

    }

    public SQLTalk() {
        for (int i = 0; i < clothes.length; i++) {
            clothes[i] = new Clothing();
        }
    }

    public Connection connectDB() {
        //step1 load the driver class
        try {
            Class.forName("oracle.jdbc.OracleDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("Where is your driver??");
        }
        //step2 create  the connection object
        Connection con = null;

        try {
            con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE", "awaken", "awaken");
        } catch (SQLException e1) {
            e1.printStackTrace();
        }

        return con;
    }

    public void disconnectDB(Connection con) {
        //step5 close the connection object
        try {
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void executeQuery(Connection con, String query) {
        //step3 create the statement object
        try {
            Statement stmt = con.createStatement();

            //step4 execute query
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String sku = rs.getString(1);
                String season = rs.getString(2);
                String gender = rs.getString(3);
                String style = rs.getString(4);
                String material = rs.getString(5);
                String iteration = rs.getString(6);
                String styleNumber = rs.getString(7);
                String color = rs.getString(8);
                String description = rs.getString(9);
                String currentPrice = rs.getString(10);
                String originalPrice = rs.getString(11);
                String size = rs.getString(12);
                String monthRecieved = rs.getString(13);
                String brandLabel = rs.getString(14);
                Clothing clothing = new Clothing(monthRecieved, brandLabel, description, currentPrice, originalPrice, season, gender, style, material, iteration, styleNumber, color, size, sku);
                for (int i = 0; i < clothes.length; i++) {
                    if (clothes[i].getSKU() == null) {
                        clothes[i] = clothing;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Failed");
        }
    }

    public void executeInput(Connection con, String input) {
        //step3 create the statement object
        try { System.out.println(input);
            PreparedStatement stmt = con.prepareStatement(input);

            //step4 execute query
            stmt.execute();

        } catch (Exception e) {
            System.out.println("Failed");

        }
    }


    public Clothing[] searchColor(String color) {
        SQLTalk connection = new SQLTalk();
        Connection con = connection.connectDB();
        String query = ("SELECT * FROM INVENTORY WHERE COLOR = '" + color + "'");
        executeQuery(con, query);
        connection.disconnectDB(con);
        return clothes;
    }

    public Clothing[] searchStyleNumber(String styleNumber) {
        SQLTalk connection = new SQLTalk();
        Connection con = connection.connectDB();
        String query = ("SELECT * FROM INVENTORY WHERE STYLENUMBER = '" + styleNumber + "'");
        executeQuery(con, query);
        connection.disconnectDB(con);
        return clothes;
    }

    public Clothing[] searchSKU(String sku) {
        SQLTalk connection = new SQLTalk();
        Connection con = connection.connectDB();
        String query = ("SELECT * FROM INVENTORY WHERE SKU = '" + sku + "'");
        executeQuery(con, query);
        connection.disconnectDB(con);
        return clothes;
    }

    public Clothing[] searchStyle(String style) {
        SQLTalk connection = new SQLTalk();
        Connection con = connection.connectDB();
        String query = ("SELECT * FROM INVENTORY WHERE STYLE = '" + style + "'");
        executeQuery(con, query);
        connection.disconnectDB(con);
        return clothes;
    }

    public Clothing[] searchDescription(String description) {
        SQLTalk connection = new SQLTalk();
        Connection con = connection.connectDB();
        String query = ("SELECT * FROM INVENTORY WHERE DESCRIPTION = '" + description + "'");
        executeQuery(con, query);
        connection.disconnectDB(con);
        return clothes;
    }

    public Clothing[] searchAll(String input) {
        SQLTalk connection = new SQLTalk();
        Connection con = connection.connectDB();
        String query = ("SELECT * FROM INVENTORY WHERE INPUT = '" + input + "'");
        executeQuery(con, query);
        connection.disconnectDB(con);
        return clothes;
    }

    public void addClothes(Clothing clothing) {
        SQLTalk connection = new SQLTalk();
        Connection con = connection.connectDB();
        String insert = ("INSERT INTO INVENTORY (SKU, SEASON, GENDER, STYLE, MATERIAL, ITERATION, STYLENUMBER, COLOR, DESCRIPTION, CURRENTPRICE, ORIGINALPRICE, ITEMSIZE, MONTHRECIEVED, BRANDLABEL) VALUES " + clothing.toInputString());
        executeInput(con, insert);
        connection.disconnectDB(con);
    }

    public void removeClothes(String sku) {
        SQLTalk connection = new SQLTalk();
        Connection con = connection.connectDB();
        String remove = (sku);
        executeQuery(con, remove);
        connection.disconnectDB(con);
    }
}
